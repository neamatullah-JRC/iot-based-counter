<?php


$servername = "localhost";
$dbname = "captaine_project001";
$username = "captaine_project001";
$password = "jrchackervau";


// Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $total = intval($_POST['total']);
    $increment = intval($_POST['increment']);
    $decrement = intval($_POST['decrement']);
    
    // Update the value in the database
  //  $sql = "UPDATE counter SET total = total + $increment , incoming = incoming + $increment WHERE id = 1";
    if ($increment == 1)
    {
            $sql = "UPDATE counter SET total = total + $increment , incoming = incoming + $increment WHERE id = 1";
     

    }else if($decrement == 1)
    {
            $sql = "UPDATE counter SET total = total - $decrement , outgoing = outgoing + $decrement WHERE id = 1";
   

    }
             if ($conn->query($sql) === TRUE) {
        echo "Value updated successfully";
    } else {
        echo "Error updating value: " . $conn->error;
    }
echo $increment;
echo $decrement;
    
}

$conn->close();

?>