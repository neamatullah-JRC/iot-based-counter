
<?php


$servername = "localhost";
$dbname = "captaine_project001";
$username = "captaine_project001";
$password = "jrchackervau";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT id, incoming, outgoing, total FROM counter";

$result = $conn->query($sql);

while ($data = $result->fetch_assoc()){
    $sensor_data[] = $data;
}

$readings_time = array_column($sensor_data, 'reading_time');



$in = json_encode(array_reverse(array_column($sensor_data, 'incoming')), JSON_NUMERIC_CHECK);
$out = json_encode(array_reverse(array_column($sensor_data, 'outgoing')), JSON_NUMERIC_CHECK);
$total = json_encode(array_reverse(array_column($sensor_data, 'total')), JSON_NUMERIC_CHECK);

$result->free();
$conn->close();
?>

<!DOCTYPE html>
<html>
    </head>
    
        <style>
            .main{
                text-align:center;
                color:red;
                font-family: Arial;
                font-size: 10rem;
                text-align: center;
            }
            .in{
                text-align:left;
                color:Green;
                font-family: Arial;
                font-size: 8rem;
            }
            .out{
                text-align:right;
                color:Blue;
                font-family: Arial;
                font-size: 8rem;
            }
            
            .center {
                display: block;
                margin-left: auto;
                margin-right: auto;
                width: 50%;
                border-radius: 50%;
            }
            .footer {
                position: fixed;
                left: 0;
                bottom: 0;
                width: 100%;
                background-color: #e6e6e6;
                color: black; 
                text-align: center;
            }
            .blink_me {
                animation: blinker 1s linear infinite;
            }

            @keyframes blinker {
                50% {
                    opacity: 0;
                }
            }
   
        </style>
         <meta http-equiv="refresh" content="3; url="<?php echo $_SERVER['PHP_SELF']; ?>">
    </head>
    <body>

<div class="main">
    
<?php
echo "Total $total";
?>
<br>
<br>
</div>
 <table style="width:100%">
<tr>
<td>
<div class="in">
    <?php
    echo "In $in";
    ?>
</div>
</td>
<td>
<div class="out">
    <?php
    echo "Out $out";
    ?>
</div>
</td>
</tr>
 </table>


    </body>
    
<div class="footer">
<h1 class="center" color="black">Powered-by</h1>
   <div class="blink_me">

 <img src="http://neamatullah-jrc.me/img/logo.jpeg" style="width:10%" class="center">
 </div>
</div>
</html>
